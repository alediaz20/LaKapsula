<footer class="mt-5">
    <div class="col-md-12 col-sm-12 col-xs-12 d-flex justify-content-between px-4" style="background-color: rgba(60, 60, 60, 30%)">
        <p class="copyright-text col-5 inline-block">Copyright &copy; 2022 All Rights Reserved by Alejandro Diaz</p>
    </div>
</footer>