<?php 
    session_unset();
?>
<script> 
    window.location.reload(); 
</script>
